package banco_de_dados;

import java.util.Locale;

public class RegistroVenda {
    public long id;
    public String nomeCliente;
    public String dataVenda;
    public double valorTotal;
    public String metodoPagamento;

    public RegistroVenda(long id, String nomeCliente, String dataVenda, double valorTotal, String metodoPagamento) {
        this.id = id;
        this.nomeCliente = nomeCliente;
        this.dataVenda = dataVenda;
        this.valorTotal = valorTotal;
        this.metodoPagamento = metodoPagamento;
    }

    @Override
    public String toString() {
        String dataFormatada = dataVenda != null && dataVenda.length() >= 16 ? dataVenda.substring(0, 16) : (dataVenda != null ? dataVenda : "Data indisponível");

        // TOSTRING() ATUALIZADO PARA MOSTRAR O MÉTODO DE PAGAMENTO
        return String.format(Locale.getDefault(),
                "ID: %d | Cliente: %s\nTotal: R$ %.2f | Pagamento: %s | Data: %s",
                id,
                nomeCliente,
                valorTotal,
                (metodoPagamento != null ? metodoPagamento : "-"),
                dataFormatada);
    }
}