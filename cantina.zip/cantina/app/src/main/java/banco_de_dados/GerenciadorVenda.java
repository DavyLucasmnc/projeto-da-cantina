package banco_de_dados;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GerenciadorVenda {
    private CantinaDBHelper dbHelper;

    // Adicionando as constantes com os nomes das tabelas
    private static final String TABELA_USUARIOS = "USUARIOS";
    private static final String TABELA_PRODUTOS = "PRODUTOS";
    private static final String TABELA_VENDAS = "VENDAS";
    private static final String TABELA_ITEM_VENDA = "ITEM_VENDA";


    public GerenciadorVenda(Context context) {
        dbHelper = new CantinaDBHelper(context);
    }

    // --- MÉTODOS PARA GERENCIAR USUÁRIOS ---

    public long inserirUsuario(Usuario usuario) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", usuario.getEmail());
        values.put("senha", usuario.getSenha());
        long id = db.insert(TABELA_USUARIOS, null, values);
        db.close();
        return id;
    }

    public boolean checarLogin(String email, String senha) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"_id"};
        String selection = "email = ? AND senha = ?";
        String[] selectionArgs = {email, senha};
        Cursor cursor = db.query(TABELA_USUARIOS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }

    // --- MÉTODOS PARA GERENCIAR PRODUTOS ---

    public long inserirProduto(Produto produto) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", produto.getNome());
        values.put("preco", produto.getPreco());
        values.put("estoque", produto.getEstoque());
        values.put("descricao", produto.getDescricao());
        long idProduto = db.insert(TABELA_PRODUTOS, null, values);
        db.close();
        return idProduto;
    }

    public boolean atualizarProduto(Produto produto) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", produto.getNome());
        values.put("preco", produto.getPreco());
        values.put("estoque", produto.getEstoque());
        values.put("descricao", produto.getDescricao());
        String whereClause = "_id = ?";
        String[] whereArgs = { String.valueOf(produto.getId()) };
        int linhasAfetadas = db.update(TABELA_PRODUTOS, values, whereClause, whereArgs);
        db.close();
        return linhasAfetadas > 0;
    }

    public boolean deletarProduto(long idProduto) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query(TABELA_ITEM_VENDA, new String[]{"_id"}, "id_produto = ?", new String[]{String.valueOf(idProduto)}, null, null, null, "1");
        if (cursor.getCount() > 0) {
            cursor.close();
            db.close();
            return false;
        }
        cursor.close();
        int linhasAfetadas = db.delete(TABELA_PRODUTOS, "_id=?", new String[]{String.valueOf(idProduto)});
        db.close();
        return linhasAfetadas > 0;
    }

    public List<Produto> listarProdutos() {
        List<Produto> listaProdutos = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selectQuery = "SELECT _id, nome, preco, estoque, descricao FROM " + TABELA_PRODUTOS + " ORDER BY nome ASC";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String nome = cursor.getString(1);
                double preco = cursor.getDouble(2);
                int estoque = cursor.getInt(3);
                String descricao = cursor.getString(4);
                listaProdutos.add(new Produto(id, nome, preco, estoque, descricao));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return listaProdutos;
    }

    public void decrementarEstoque(long idProduto, int quantidadeVendida) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String sql = "UPDATE " + TABELA_PRODUTOS + " SET estoque = estoque - " + quantidadeVendida + " WHERE _id = " + idProduto;
        db.execSQL(sql);
        db.close();
    }


    // --- MÉTODOS PARA GERENCIAR VENDAS ---

    public long inserirVenda(String nomeCliente, double valorTotal, String metodoPagamento) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        String dataHoraAtual = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        values.put("nome_cliente", nomeCliente);
        values.put("data_venda", dataHoraAtual);
        values.put("valor_total", valorTotal);
        values.put("metodo_pagamento", metodoPagamento);
        long idVenda = db.insert(TABELA_VENDAS, null, values);
        db.close();
        return idVenda;
    }

    public void inserirItemVenda(long idVenda, ItemVenda item) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id_venda", idVenda);
        values.put("id_produto", item.idProduto);
        values.put("quantidade", item.quantidade);
        values.put("preco_no_momento_da_venda", item.precoNoMomentoDaVenda);
        db.insert(TABELA_ITEM_VENDA, null, values);
        db.close();
    }

    public void deletarVendaPorId(long idVenda) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABELA_ITEM_VENDA, "id_venda = ?", new String[]{String.valueOf(idVenda)});
        db.delete(TABELA_VENDAS, "_id = ?", new String[]{String.valueOf(idVenda)});
        db.close();
    }

    public void limparHistoricoVendas() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABELA_ITEM_VENDA, null, null);
        db.delete(TABELA_VENDAS, null, null);
        db.close();
    }

    public List<RegistroVenda> listarVendas() {
        List<RegistroVenda> listaVendas = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selectQuery = "SELECT _id, nome_cliente, data_venda, valor_total, metodo_pagamento FROM " + TABELA_VENDAS + " ORDER BY _id DESC";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String nomeCliente = cursor.getString(1);
                String dataVenda = cursor.getString(2);
                double valorTotal = cursor.getDouble(3);
                String metodoPagamento = cursor.getString(4);
                listaVendas.add(new RegistroVenda(id, nomeCliente, dataVenda, valorTotal, metodoPagamento));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return listaVendas;
    }

    public List<String> buscarItensDetalhesPorVendaId(long vendaId) {
        List<String> itensFormatados = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT P.nome, P.descricao, IV.quantidade, IV.preco_no_momento_da_venda " +
                "FROM " + TABELA_ITEM_VENDA + " AS IV " +
                "INNER JOIN " + TABELA_PRODUTOS + " AS P ON IV.id_produto = P._id " +
                "WHERE IV.id_venda = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(vendaId)});
        if (cursor.moveToFirst()) {
            do {
                String nomeProduto = cursor.getString(0);
                String descricaoProduto = cursor.getString(1);
                int quantidade = cursor.getInt(2);
                double precoUnitario = cursor.getDouble(3);
                String itemInfo = String.format(Locale.getDefault(),
                        "Produto: %s\nDescrição: %s\n%d x R$ %.2f",
                        nomeProduto,
                        (descricaoProduto != null && !descricaoProduto.isEmpty() ? descricaoProduto : "-"),
                        quantidade,
                        precoUnitario);
                itensFormatados.add(itemInfo);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itensFormatados;
    }
}