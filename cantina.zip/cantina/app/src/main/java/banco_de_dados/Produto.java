package banco_de_dados;

import java.util.Locale;

/**
 * Classe modelo (Entidade) para representar um registro da tabela PRODUTOS.
 * Este é um item do catálogo de produtos disponíveis para venda.
 */
public class Produto {

    private long id;
    private String nome;
    private double preco;
    private int estoque;
    private String descricao;

    // Construtor
    public Produto(long id, String nome, double preco, int estoque, String descricao) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.estoque = estoque;
        this.descricao = descricao;
    }

    // --- Getters ---
    // Métodos para permitir que outras classes acessem os dados de forma segura.

    public long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public String getDescricao() {
        return descricao;
    }

    /**
     * Este método é muito importante!
     * O Android vai chamá-lo automaticamente para decidir o que exibir
     * na lista (Spinner) da VendasActivity cuidado ao alterar pra não bagaçar tudo!
     *
     * @return Uma representação em texto do produto para exibição.
     */
    // Dentro da classe Produto.java

    @Override
    public String toString() {
        // Formata o texto para incluir nome, preço, estoque e descrição
        return String.format(Locale.getDefault(),
                "%s - R$ %.2f\nEstoque: %d | Descrição: %s",
                nome,
                preco,
                estoque,
                (descricao != null && !descricao.isEmpty() ? descricao : "-")
        );
    }}