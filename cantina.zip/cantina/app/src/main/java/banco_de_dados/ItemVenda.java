package banco_de_dados;

/**
 * VERSÃO CORRETA E SIMPLIFICADA
 * Classe modelo (Entidade) para representar um item vendido na transação.
 * Guarda apenas as informações específicas da venda (qual produto, quantos e por qual preço).
 */
public class ItemVenda {

    public long idProduto;
    public int quantidade;
    public double precoNoMomentoDaVenda;

    // Construtor com 3 argumentos
    public ItemVenda(long idProduto, int quantidade, double precoNoMomentoDaVenda) {
        this.idProduto = idProduto;
        this.quantidade = quantidade;
        this.precoNoMomentoDaVenda = precoNoMomentoDaVenda;
    }
}